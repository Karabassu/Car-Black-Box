
#ifndef DASH_BOARD_H
#define	DASH_BOARD_H

void dash_board(void); 
void store(void);

#endif	

