#include "main.h"

extern unsigned int state;
extern int star;
extern int event_count;
int acount=0;
char data;
char arr[15];
int a;

extern int log_index;

//unsigned int view_addr = 0x00;

extern int address;

//////////////////////////////////////////////////////////////////////////
void download(void)
{
    if (event_count == 0) 
    {
        clcd_print("NO LOGS       ", LINE1(0));         // Display "NO LOGS" on the first line
        clcd_print("    ARE FOUND", LINE2(0));          // Display "ARE FOUND" on the second line
        for (unsigned long wait = 500000; wait--; );    // Wait for a while
        state = MAIN_MENUE;                             // Set state to MAIN_MENUE
        CLEAR_DISP_SCREEN;                              // Clear the display screen
        return;
    }

    clcd_print("DOWNLOADING    ", LINE1(0));            // Display "DOWNLOADING" on the first line
    clcd_print("....  ", LINE2(0));                     // Display "...." on the second line

    for (int i = 0; i < event_count; i++)
    {
        int current_event = (log_index + i) % 10;           // Calculate the current event index
        address = current_event * 10;                       // Calculate the EEPROM address for the current event

        char event_log[16];
        event_log[0] = read_external_eeprom(address++);         // Read hour tens digit
        event_log[1] = read_external_eeprom(address++);         // Read hour units digit
        event_log[2] = ':';                                 // Add colon separator
        event_log[3] = read_external_eeprom(address++);         // Read minute tens digit
        event_log[4] = read_external_eeprom(address++);     // Read minute units digit
        event_log[5] = ':';                                         // Add colon separator
        event_log[6] = read_external_eeprom(address++);     // Read second tens digit
        event_log[7] = read_external_eeprom(address++);     // Read second units digit
        event_log[8] = ' ';                                     // Add space
        event_log[9] = read_external_eeprom(address++);     // Read event type tens digit
        event_log[10] = read_external_eeprom(address++);    // Read event type units digit
        event_log[11] = ' ';                                        // Add space
        event_log[12] = read_external_eeprom(address++);    // Read event data tens digit
        event_log[13] = read_external_eeprom(address++);    // Read event data units digit
        event_log[14] = '\r';                               // Add carriage return
        event_log[15] = '\n';                                    // Add newline

        for (int j = 0; j < 16; j++)
        {
            //putch(j+'0');
            putch(event_log[j]);        // Send the event log character to the output
        }
    }
    
    for (unsigned long wait = 500000; wait--; ); // Wait for a while
    state = MAIN_MENUE;             // Set state to MAIN_MENUE
    CLEAR_DISP_SCREEN;              // Clear the display screen
}
