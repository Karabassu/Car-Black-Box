#ifndef MAIN_H
#define	MAIN_H


#include <xc.h>
#include "clcd.h"
#include "dash_board.h"
#include "external_eeprom.h"
#include "main_menue.h"
#include "mkp.h"
#include "ds1307.h"
#include "i2c.h"
#include "uart.h"


enum
{
    DASH_BOARD,
    MAIN_MENUE,
    VIEW_LOG,
    DOWNLOAD_LOG,
    CLEAR_LOG,
    SET_TIME
};

void clear_log(void);
void download(void) ;
static void get_time(void);

void view_log(void);
void display_time(void);
void set_time(void);
void clear_log(void);
void download(void) ;
 void event_reader(void);
 
 void print_clcd(void);
#endif

