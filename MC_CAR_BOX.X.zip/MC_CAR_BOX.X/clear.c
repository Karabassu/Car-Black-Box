#include "main.h"

extern int event_count;
extern int address;
extern unsigned int state;
extern int star;

void clear_log(void)
{
   //CLEAR_DISP_SCREEN;
   
    star=0;                     // Reset star to 0

   event_count=0;               // Reset event count to 0
   address=0;                   // Reset address to 0
   
   clcd_print("clearing....",LINE1(0)); // Display "clearing...." on the first line
   for(unsigned long int i=600000; i--;); // Wait for a while
   state=MAIN_MENUE; // Set state to MAIN_MENUE
}
