#ifndef MAIN_MENUE_H
#define	MAIN_MENUE_H

void main_menue(void);
#endif	/* MAIN_MENUE_H */

