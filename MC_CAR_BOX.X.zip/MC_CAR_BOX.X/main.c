/*
 NAME : Karabasu Sangur
 DATE : 05/01/2025
 DESCRIPTION : CAR BLACK BOX
 Black Box implementation in an Automotive System to log critical events. 
 This will help in pro-active vehicle monitoring and maintenance.
 */
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#include "main.h"
// Global variables
unsigned char key = 0;            // Variable to store the key pressed
int flag = 1;                     // Flag variable
unsigned int state;               // Variable to store the current state

extern int star;                  // External variable
int log_index = 0;                // Index for logging
////////////////////////////////////////////

// Function to initialize the car's configuration
static void init_configcar(void) 
{
    init_clcd();                    // Initialize the CLCD
    init_adc();                     // Initialize the ADC
    init_mkp();                     // Initialize the matrix keypad
    init_i2c();                     // Initialize the I2C
    init_ds1307();                  // Initialize the DS1307 RTC
    init_uart();                    // Initialize the UART
}

// Main function
void main(void) 
{
    init_configcar();                     // Call the initialization function
    
    while (1)                               // Infinite loop
    {
        key = read_matrix_keypad(STATE);    // Read the key pressed from the matrix keypad

        switch (state)                     // Switch case to handle different states
        {
            case DASH_BOARD:
                dash_board();               // Display the dashboard
                if (key == SW4)             // If key SW4 is pressed
                {
                    CLEAR_DISP_SCREEN;      // Clear the display screen
                    state = MAIN_MENUE;     // Change state to MAIN_MENUE
                }
                break;

            case MAIN_MENUE:
                main_menue();                   // Display the main menu
                if (key == SW5)                 // If key SW5 is pressed
                {
                    CLEAR_DISP_SCREEN;          // Clear the display screen
                    star = 0;                   // Reset star variable
                    log_index = 0;              // Reset log index
                    state = DASH_BOARD;         // Change state to DASH_BOARD
                }
                break;

            case VIEW_LOG:
                view_log();                     // Display the log
                if (key == SW5)                 // If key SW5 is pressed
                {
                    star = 0;                   // Reset star variable
                    log_index = 0;              // Reset log index
                    CLEAR_DISP_SCREEN;          // Clear the display screen
                    state = MAIN_MENUE;         // Change state to MAIN_MENUE
                }
                break;

            case CLEAR_LOG:
                star = 0;                      // Reset star variable
                log_index = 0;                 // Reset log index
                clear_log();                   // Clear the log
                if (key == SW5)                // If key SW5 is pressed
                {
                    CLEAR_DISP_SCREEN;         // Clear the display screen
                    state = MAIN_MENUE;        // Change state to MAIN_MENUE
                }
                break;

            case DOWNLOAD_LOG:
                star = 0;                       // Reset star variable
                log_index = 0;                  // Reset log index
                download();                     // Download the log
                if (key == SW5)                  // If key SW5 is pressed
                {
                    CLEAR_DISP_SCREEN;          // Clear the display screen
                    state = MAIN_MENUE;         // Change state to MAIN_MENUE
                }
                break;

            case SET_TIME:
                star = 0;                       // Reset star variable
                log_index = 0;                  // Reset log index
                set_time();                     // Set the time
                if (key == SW5)                 // If key SW5 is pressed
                {
                    star = 0;                   // Reset star variable
                    log_index = 0;              // Reset log index
                    CLEAR_DISP_SCREEN;          // Clear the display screen
                    state = MAIN_MENUE;         // Change state to MAIN_MENUE
                }
                break;
        }
    }
}
