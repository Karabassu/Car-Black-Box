#include "main.h"


/* 
 * DS1307 Slave address
 * D0  -  Write Mode
 * D1  -  Read Mode
 */
//////////////////////////////////////////////////////////
unsigned char clock_reg[3];
unsigned char calender_reg[4];
unsigned char time[9];
unsigned char date[11];
////////////////////////////////////////////////////////
void init_ds1307(void)
{
	unsigned char dummy;

    
	dummy = read_ds1307(HOUR_ADDR);
	write_ds1307(HOUR_ADDR, dummy | 0x40); 
    
    dummy = read_ds1307(HOUR_ADDR);
	write_ds1307(HOUR_ADDR, (dummy & 0xC0) |0X24); 
    
    dummy=read_ds1307(MIN_ADDR);
    write_ds1307(MIN_ADDR,0X21);
    
    dummy=read_ds1307(SEC_ADDR);
    write_ds1307(SEC_ADDR,(dummy& 0X80)|0x05);
    

	/* 
	 * Control Register of DS1307
	 * Bit 7 - OUT
	 * Bit 6 - 0
	 * Bit 5 - OSF
	 * Bit 4 - SQWE
	 * Bit 3 - 0
	 * Bit 2 - 0
	 * Bit 1 - RS1
	 * Bit 0 - RS0
	 * 
	 * Seting RS0 and RS1 as 11 to achive SQW out at 32.768 KHz
	 */ 
    
	write_ds1307(CNTL_ADDR, 0x93); 

	/* Clearing the CH bit of the RTC to Start the Clock */
	dummy = read_ds1307(SEC_ADDR);
	write_ds1307(SEC_ADDR, dummy & 0x7F); 
    
   
}

void write_ds1307(unsigned char address, unsigned char data)
{
	i2c_start();
	i2c_write(SLAVE_WRITE);
	i2c_write(address);
	i2c_write(data);
	i2c_stop();
}

unsigned char read_ds1307(unsigned char address)
{
	unsigned char data;

	i2c_start();
	i2c_write(SLAVE_WRITE);
	i2c_write(address);
	i2c_rep_start();
	i2c_write(SLAVE_READ);
	data = i2c_read();
	i2c_stop();

	return data;
}