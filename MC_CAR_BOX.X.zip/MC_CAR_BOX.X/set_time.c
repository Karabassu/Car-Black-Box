#include "main.h"

extern unsigned int state;
extern int star;
extern int event_count;
extern unsigned char key;
extern unsigned char time[9];

unsigned int flag1=0,delay1=0;
unsigned int hour=0,min=0,sec=0;

void set_time(void) 
{
   clcd_print("    HR:MN:SC   ", LINE1(0)); // Display the header "HR:MN:SC" on the first line

    if (flag1 == 0)  // Extract time and convert into numeric values
    {
        hour = ((time[0] - '0') * 10) + (time[1] - '0'); // Convert hour from string to integer
        min = ((time[3] - '0') * 10) + (time[4] - '0');  // Convert minute from string to integer
        sec = ((time[6] - '0') * 10) + (time[7] - '0');  // Convert second from string to integer
        flag1++;
    }

    // Handle incrementing time values (hours, minutes, seconds)
    if (key == SW1) 
    {
        if (flag1 == 1)  // Increment hour
        {
            hour = (hour + 1) % 24; // Increment hour and wrap around at 24
        }
        else if (flag1 == 2)  // Increment minute
        {
            min = (min + 1) % 60; // Increment minute and wrap around at 60
        }
        else if (flag1 == 3)  // Increment second
        {
            sec = (sec + 1) % 60; // Increment second and wrap around at 60
        }
    }

    // Blink hour field
    if (flag1 == 1)
    {
        if (delay1 ++< 500) 
        {
            print_clcd(); // Display the current time
        } 
        else if (delay1 ++< 1000) 
        {
            clcd_print("  ", LINE2(4)); // Clear the hour field
        } 
        else 
        {
            delay1 = 0; // Reset delay
        }
    }
    // Blink minute field
    if (flag1 == 2) 
    {
        if (delay1++ < 500) 
        {
            print_clcd(); // Display the current time
        } 
        else if (delay1++ < 1000)
        {
            clcd_print("  ", LINE2(7)); // Clear the minute field
        } 
        else 
        {
            delay1 = 0; // Reset delay
        }
    }
    // Blink second field
    if (flag1 == 3) 
    {
        if (delay1++ < 500) 
        {
            print_clcd(); // Display the current time
        } 
        else if (delay1++ < 1000) 
        {
            clcd_print("  ", LINE2(10)); // Clear the second field
        } 
        else 
        {
            delay1 = 0; // Reset delay
        }
    }

    // Switch field on SW2 press
    if (key == SW2) 
    {
        if (++flag1 == 4) 
        {
            flag1 = 1;  // Reset flag1 to 1 after 3 fields
        }
    }

    // Save time to RTC on SW1 press
    if (key == SW4) 
    {
        CLEAR_DISP_SCREEN; // Clear the display screen
        write_ds1307(HOUR_ADDR, (((hour / 10) << 4) | (hour % 10))); // Write hour to RTC
        write_ds1307(MIN_ADDR, (((min / 10) << 4) | (min % 10))); // Write minute to RTC
        write_ds1307(SEC_ADDR, (((sec / 10) << 4) | (sec % 10))); // Write second to RTC
   
        state = DASH_BOARD;  // Go back to main menu
    }
    if (key == SW5) 
    {
        state = MAIN_MENUE; // Go back to main menu
    }
}

void print_clcd(void)
{
    // Display hour value
    clcd_putch(hour / 10 + '0', LINE2(4));      // Display tens digit of hour
    clcd_putch(hour % 10 + '0', LINE2(5));      // Display units digit of hour
    clcd_putch(':', LINE2(6));                  // Display colon separator
    
    // Display minute value
    clcd_putch(min / 10 + '0', LINE2(7));       // Display tens digit of minute
    clcd_putch(min % 10 + '0', LINE2(8));       // Display units digit of minute
    clcd_putch(':', LINE2(9));                  // Display colon separator
    
    // Display second value
    clcd_putch(sec / 10 + '0', LINE2(10));      // Display tens digit of second
    clcd_putch(sec % 10 + '0', LINE2(11));      // Display units digit of second
}
