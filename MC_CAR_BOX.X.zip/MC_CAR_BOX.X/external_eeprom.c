#include "main.h"
#include "i2c.h"
#include "external_eeprom.h"

// Function to write data to external EEPROM
void write_external_eeprom(unsigned char address, unsigned char data)
{
    i2c_start();                // Start I2C communication
    i2c_write(0xA0);            // Send EEPROM write command
    i2c_write(address);         // Send address to write to
    i2c_write(data);            // Send data to write
    i2c_stop();                 // Stop I2C communication
    for(unsigned long wait = 3000; wait--;); // Wait for EEPROM write cycle to complete
}

// Function to read data from external EEPROM
unsigned char read_external_eeprom(unsigned char address)
{
    unsigned char data;

    i2c_start();                // Start I2C communication
    i2c_write(0xA0);            // Send EEPROM write command
    i2c_write(address);         // Send address to read from
    i2c_rep_start();            // Send repeated start condition
    i2c_write(0XA1);            // Send EEPROM read command
    data = i2c_read();          // Read data from EEPROM
    i2c_stop();                 // Stop I2C communication

    return data;                // Return the read data
}
