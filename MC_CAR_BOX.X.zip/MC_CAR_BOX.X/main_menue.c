#include "main.h"

int i=0;
extern unsigned char key;

int star=0;
extern unsigned int state;

char menue_flag=0;
extern int log_index;
int menue_count=2;
//int state;
////////////////////////////////////////////////////////////////////////////////
//e-num/////////////////////////////////////////////////////////////////////////
/*typedef enum
{
    VIEW_LOG=SW1,
    CLEAR_LOG,
    DOWNLOAD_LOG,
    SET_TIME
}LOG;*/
////////////////////////////////////////////////////////////////////////////////
char logarr[4][16]={"VIEW_LOG       ","CLEAR_LOG      ","DOWNLOAD_LOG     ","SET_TIME     "};
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void main_menue(void)
{
    if(star == 0)
    {
        clcd_putch('*', LINE1(0));              // Display '*' on the first line if star is 0
        clcd_print(" ", LINE2(0));              // Clear the first character on the second line
    }
    else
    {        
       clcd_print(" ", LINE1(0));               // Clear the first character on the first line
       clcd_putch('*', LINE2(0));               // Display '*' on the second line if star is 1
    }
    clcd_print(logarr[log_index],LINE1(1));     // Print the current log on the first line
    clcd_print(logarr[log_index+1],LINE2(1));       // Print the next log on the second line

    // Handle key presses for navigation
    if (key != ALL_RELEASED)
    {
        // If SW2 is pressed, scroll down
        if (key == SW2)
        {
            if(star == 0)
            {
                star = 1;                                    // Move the '*' to the second line
            }
            else if (log_index < menue_count)               // Stop at the last option
            {
                log_index++;                                // Scroll down to next menu
            }
        }
        // If SW1 is pressed, scroll up
        else if (key == SW1)
        {
            if(star == 1)
            {
                star = 0;                                   // Move the '*' to the first line
            }
            else if (log_index > 0)                        // Stop at the first option
            {
                log_index--;                                // Scroll up to previous menu
            }
        }
        // If SW4 is pressed, select the current menu
        else if(key == SW4)
        {
            switch(star+log_index)
            {
            case 0: 
            {
                // Call view function
                // view_log();
                CLEAR_DISP_SCREEN;
                state=VIEW_LOG;                 // Set state to VIEW_LOG
            }
            break;
            case 1:
            {
                // Call clear function
                CLEAR_DISP_SCREEN;
                state=CLEAR_LOG;                // Set state to CLEAR_LOG
                // clear_log();
            }
            break;
            case 2:
            {
                // Call download log function
                // download();
                CLEAR_DISP_SCREEN;
                state=DOWNLOAD_LOG;                // Set state to DOWNLOAD_LOG
            }
            break;
            case 3:
            {
                // Call set time function
                // set_time();
                CLEAR_DISP_SCREEN;
                state=SET_TIME;                     // Set state to SET_TIME
            }
            break;
            }
        }
    }
}
////////////////////////////////////////////////////////////////////////////////