#include "main.h"

extern int event_count;
char viewarr[10][15];
extern int address=0x00;
extern int log_index;
extern int star;
extern unsigned char key;
extern unsigned int state;

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void view_log(void)
{
    clcd_print("#   TIME   EV SP ", LINE1(0));
    event_reader();  // Read events from EEPROM

    if (event_count == 0)
    {
        clcd_print("VIEW LOG IS         ", LINE1(0));
        clcd_print("EMPTY", LINE2(5));
        for(unsigned long int wait=600000;wait--;);
        state=MAIN_MENUE;
    }

    // Navigate through logs
    if (key == SW2 && log_index < event_count - 1)  // Scroll down
    {
        log_index++;
    }
    if (key == SW1 && log_index > 0)  // Scroll up
    {
        log_index--;
    }
    
    // Reset to the first log if index exceeds event count
    if (log_index >= event_count) 
    {
        log_index = 0;
    }

    // Display current log data in LINE2
    clcd_putch(log_index + '0', LINE2(0));  // Display log index (0 to 9)
    clcd_print(" ", LINE2(1));  // Empty space
    clcd_print(viewarr[log_index], LINE2(2));  // Display the log entry
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Function to read logs from EEPROM
void event_reader(void)
{
    address = 0;  // Initialize address for EEPROM reading
    // Read every log entry from external EEPROM
    for (int i = 0; i < event_count; i++) 
    {
        for (int j = 0; j < 15; j++) 
        {
            if (j == 8 || j == 11) 
            {
                viewarr[i][j] = ' ';
                
            }
            else if (j == 2 || j == 5)
            {
                viewarr[i][j] = ':'; 
            }
            else if (j == 14) 
            {
                viewarr[i][j] = '\0';  // Null terminate string
            }
            else 
            {
               
            viewarr[i][j] = read_external_eeprom(address++);
                
            }
        }
    }
} 


// Placeholder for download log functionality (to be implemented)


//////////////////////////////////////////////////////////////////////

 void clearLog(void)
{
   event_count=0; 
   clcd_print("  LOGS CLEARED  ", LINE1(0));
   clcd_print("  SUCCESSFULLY  ", LINE2(0));
   for(unsigned long int wait=600000;wait--;);
   state=MAIN_MENUE;
   
   

}  
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

