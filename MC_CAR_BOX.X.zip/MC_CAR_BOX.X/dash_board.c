#include "main.h"

extern unsigned char key;
//////////////////////////////////////////////////////////////////////////////////////
//char time[9]="00:00:00";
//unsigned int Reg_val;
unsigned char speed;

char garr[8][3]={"ON","GN","GR","G1","G2","G3","G4","C "}; // Array of event strings
///////////////////////////////////////////////////////////////////////////////////
char stor_write_arr[10];
char stor_read_arr[11];

int count=0;
char ch;
int address=0;
int event_count=0;
/////////////////////////////////////////////////////////////////////////////////////////

unsigned char clock_reg[3];
unsigned char calender_reg[4];
unsigned char time[9];
unsigned char date[11];
///////////////////////////////////////////////////////////////////////////////////////
 int gindex=0;
unsigned int collision=0;

void dash_board(void) 
{
        get_time();                 // Get the current time
        
        clcd_print(time, LINE2(0));         // Display the current time on the second line
        clcd_print("TIME      EV  SP", LINE1(0)); // Display the header on the first line
        //CLEAR_DISP_SCREEN;
        clcd_print(stor_read_arr,LINE1(0));                  // Display stored data on the first line
        speed = read_adc(CHANNEL4)/10.33;                       // Read and calculate the speed
        
        //speed = Reg_val/10.33;
        
        clcd_putch((speed/10%10)+48, LINE2(14)); // Display the tens digit of speed
        clcd_putch((speed%10)+48, LINE2(15)); // Display the units digit of speed
        
/////////////////////Matrix keypad///////////////////////////////////////////////////////////////////////////////////////////// 
        if(key != ALL_RELEASED) // Read key value from the matrix keypad  
        {
            if(key == SW1 /*&& gindex!=1*/)
            {
                // Write to EEPROM
                gindex=7;
                collision=1;
                store(); // Write to EEPROM
            }
            else if(key == SW2 && gindex<6 && collision!=1)
            {
                gindex++; // Increment event 
                store(); // Write to EEPROM
            }
            else if(key == SW3 && gindex>1 && collision!=1)
            {
                gindex--; // Decrement event
                store(); // Write to EEPROM
            }
            else if(collision==1 && key!=SW4 && key !=SW5 )
            {
                gindex=1;
                collision=0;
                store(); // Write to EEPROM
            }
        }
         
    clcd_print(garr[gindex], LINE2(10)); // Display the current event on the second line
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void store(void)
{
    if (address >= 100) 
    {
        address = 0; // Reset address if it exceeds 100
    }

    write_external_eeprom(address++, time[0]);              // Write hour tens digit to EEPROM
    write_external_eeprom(address++, time[1]);               // Write hour units digit to EEPROM
    write_external_eeprom(address++, time[3]);               // Write minute tens digit to EEPROM
    write_external_eeprom(address++, time[4]);               // Write minute units digit to EEPROM
    write_external_eeprom(address++, time[6]);               // Write second tens digit to EEPROM
    write_external_eeprom(address++, time[7]);               // Write second units digit to EEPROM

    if (collision) 
    {
        write_external_eeprom(address++, '-');               // Write collision indicator to EEPROM
        write_external_eeprom(address++, 'C');               // Write collision indicator to EEPROM
    } 
    else 
    {
        write_external_eeprom(address++, garr[gindex][0]);               // Write event type to EEPROM
        write_external_eeprom(address++, garr[gindex][1]);               // Write event type to EEPROM
    }

    write_external_eeprom(address++, (speed / 10) + '0');               // Write speed tens digit to EEPROM
    write_external_eeprom(address++, (speed % 10) + '0');               // Write speed units digit to EEPROM
    
    if (event_count < 10)
    {
        event_count++; // Increment event count if less than 10
    }
    else
    {    
        gindex = (gindex + 1) % 10; // Wrap around event index
    }    
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

static void get_time(void)
{
    clock_reg[0] = read_ds1307(HOUR_ADDR); // Read hour from RTC
    clock_reg[1] = read_ds1307(MIN_ADDR); // Read minute from RTC
    clock_reg[2] = read_ds1307(SEC_ADDR); // Read second from RTC

    if (clock_reg[0] & 0x40)
    {
        time[0] = '0' + ((clock_reg[0] >> 4) & 0x01); // Extract tens digit of hour
        time[1] = '0' + (clock_reg[0] & 0x0F); // Extract units digit of hour
    }
    else
    {
        time[0] = '0' + ((clock_reg[0] >> 4) & 0x03); // Extract tens digit of hour
        time[1] = '0' + (clock_reg[0] & 0x0F); // Extract units digit of hour
    }
    time[2] = ':'; // Add colon separator
    time[3] = '0' + ((clock_reg[1] >> 4) & 0x0F); // Extract tens digit of minute
    time[4] = '0' + (clock_reg[1] & 0x0F); // Extract units digit of minute
    time[5] = ':'; // Add colon separator
    time[6] = '0' + ((clock_reg[2] >> 4) & 0x0F); // Extract tens digit of second
    time[7] = '0' + (clock_reg[2] & 0x0F); // Extract units digit of second
    time[8] = '\0'; // Null-terminate the time string
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
